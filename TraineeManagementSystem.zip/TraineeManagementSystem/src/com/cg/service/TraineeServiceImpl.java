package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.ITraineeDao;
import com.cg.dao.TraineeDaoImpl;
import com.cg.exception.TraineeException;
@Service
public class TraineeServiceImpl implements ITraineeService {
	
	
	
//  Business bc = (Business)context.getBean("myBusinessClass");
//	TraineeDaoImpl traineeDao=(TraineeDaoImpl)ctx.getBean("traineeDao");
	@Autowired
	ITraineeDao traineeDao;
	public ITraineeDao getTraineeDao()throws TraineeException {
		return traineeDao;
	}







	public void setTraineeDao(ITraineeDao traineeDao)throws TraineeException {
		this.traineeDao = (TraineeDaoImpl) traineeDao;
	}




	


	@Override
	public Trainee addTrainee(Trainee bean)throws TraineeException {
		
		return traineeDao.addTrainee(bean);
	}




	@Override
	public Trainee deleteTrainee(int id)throws TraineeException {
		
		return traineeDao.deleteTrainee(id);
	}




	@Override
	public Trainee viewTrainee(int id)throws TraineeException {
		
		return traineeDao.viewTrainee(id);
	}




	@Override
	public List<Trainee> viewAllTrainees()throws TraineeException {
			
		return traineeDao.viewAllTrainees();
	}




	@Override
	public boolean updateTrainee(Trainee bean) throws TraineeException {
		
		return traineeDao.updateTrainee(bean);
	}

}
